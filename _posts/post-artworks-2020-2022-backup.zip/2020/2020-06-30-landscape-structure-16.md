---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape-structure #16"
caption: "landscape-structure #16_oil on canvas_33×24㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-16.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-16.jpg
order: 2020008
---
