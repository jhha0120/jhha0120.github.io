---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape-structure #22"
caption: "landscape-structure #22_oil on canvas_33×24㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-22.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-22.jpg
order: 2020014
---
