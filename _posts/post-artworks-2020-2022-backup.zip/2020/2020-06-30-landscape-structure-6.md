---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape-structure #6"
caption: "landscape-structure #6_acrylic oil on canvas_150×105㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-6.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-6.jpg
order: 2020016
---
