---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "structure of flower #5"
caption: "structure of flower #5_oil on canvas_33×24㎝_2020"
image: /assets/images/artworks/2020/structure-of-flower-5.jpg
thumb: /assets/images/artworks/2020/thumbs/structure-of-flower-5.jpg
order: 2020001
---
