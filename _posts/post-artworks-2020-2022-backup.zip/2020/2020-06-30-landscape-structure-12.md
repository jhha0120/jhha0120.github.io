---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape-structure #12"
caption: "landscape-structure #12_oil on canvas_33×24㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-12.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-12.jpg
order: 2020004
---
