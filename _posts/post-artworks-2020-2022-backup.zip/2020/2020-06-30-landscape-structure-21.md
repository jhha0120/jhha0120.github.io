---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape-structure #21"
caption: "landscape-structure #21_oil on canvas_33×24㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-21.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-21.jpg
order: 2020013
---
