---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape-structure #9(Aix-en-Provence)"
caption: "landscape-structure #9(Aix-en-Provence)_acrylic oil on canvas_117×91㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-9.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-9.jpg
order: 2020019
---
