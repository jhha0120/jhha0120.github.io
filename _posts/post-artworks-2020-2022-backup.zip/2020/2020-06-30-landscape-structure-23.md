---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape-structure #23(Aix-en-Provence)"
caption: "landscape-structure #23(Aix-en-Provence)_acrylic oil on canvas_91×117㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-23.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-23.jpg
order: 2020020
---
