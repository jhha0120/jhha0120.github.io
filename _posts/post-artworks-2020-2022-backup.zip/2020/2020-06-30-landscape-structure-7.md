---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape-structure #7(corsica)"
caption: "landscape-structure #7(corsica)_acrylic oil on canvas_117×91㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-7.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-7.jpg
order: 2020018
---
