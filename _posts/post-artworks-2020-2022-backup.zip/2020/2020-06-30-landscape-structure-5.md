---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape structure #5"
caption: "landscape structure #5(corsica)_acrylic oil on canvas_150×150㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-5.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-5.jpg
order: 2020015
---
