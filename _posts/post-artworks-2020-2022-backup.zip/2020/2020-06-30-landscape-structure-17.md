---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape-structure #17"
caption: "landscape-structure #17_oil on canvas_33×24㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-17.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-17.jpg
order: 2020009
---
