---
layout: "artwork"
categories: "2020-2019"
author: "Jihoon Ha"
title: "landscape-structure #11"
caption: "landscape-structure #11_oil on canvas_33×24㎝_2020"
image: /assets/images/artworks/2020/landscape-structure-11.jpg
thumb: /assets/images/artworks/2020/thumbs/landscape-structure-11.jpg
order: 2020003
---
