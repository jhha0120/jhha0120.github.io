---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "landscape-structure #28(sunset)"
caption: "landscape-structure #28(sunset)_acrylic,oil on canvas_33×24㎝_2021"
image: /assets/images/artworks/2021/landscape-structure--28_sunset.jpg
thumb: /assets/images/artworks/2021/thumbs/landscape-structure--28_sunset.jpg
order: 2021005
---
