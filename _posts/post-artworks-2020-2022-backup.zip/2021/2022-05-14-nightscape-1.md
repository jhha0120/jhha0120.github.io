---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "Nightscape#1"
caption: "Nightscape#1_acrylic,oil on canvas_73×61㎝_2021"
image: /assets/images/artworks/2021/nightscape-1.jpg
thumb: /assets/images/artworks/2021/thumbs/nightscape-1.jpg
order: 2021054
---
