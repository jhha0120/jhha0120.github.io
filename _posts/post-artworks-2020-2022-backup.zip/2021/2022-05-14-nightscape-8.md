---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "Nightscape#8"
caption: "Nightscape#8_acrylic,oil on canvas_73×61㎝_2021"
image: /assets/images/artworks/2021/nightscape-8.jpg
thumb: /assets/images/artworks/2021/thumbs/nightscape-8.jpg
order: 2021088
---
