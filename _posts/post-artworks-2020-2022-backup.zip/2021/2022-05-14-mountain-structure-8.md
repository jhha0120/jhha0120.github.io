---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "mountain-structure#8"
caption: "mountain-structure#8_acrylic,oil on canvas_33×24㎝_2021"
image: /assets/images/artworks/2021/mountain-structure-8.jpg
thumb: /assets/images/artworks/2021/thumbs/mountain-structure-8.jpg
order: 2021017
---
