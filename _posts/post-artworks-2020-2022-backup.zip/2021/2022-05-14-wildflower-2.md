---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "wildflower#2"
caption: "wildflower#2_oil on canvas_33×24㎝_2021"
image: /assets/images/artworks/2021/wildflower-2.jpg
thumb: /assets/images/artworks/2021/thumbs/wildflower-2.jpg
order: 2021038
---
