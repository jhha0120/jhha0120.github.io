---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "Nightscape#9"
caption: "Nightscape#9_acrylic,oil on canvas_46×53㎝_2021"
image: /assets/images/artworks/2021/nightscape-9.jpg
thumb: /assets/images/artworks/2021/thumbs/nightscape-9.jpg
order: 2021051
---
