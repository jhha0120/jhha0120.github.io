---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "mountain-structure#6"
caption: "mountain-structure#6_acrylic,oil on canvas_33×24㎝_2021"
image: /assets/images/artworks/2021/mountain-structure-6.jpg
thumb: /assets/images/artworks/2021/thumbs/mountain-structure-6.jpg
order: 2021015
---
