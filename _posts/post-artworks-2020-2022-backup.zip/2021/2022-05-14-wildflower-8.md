---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "wildflower#8"
caption: "wildflower#8_acrylic,oil on canvas_33×24㎝_2021"
image: /assets/images/artworks/2021/wildflower-8.jpg
thumb: /assets/images/artworks/2021/thumbs/wildflower-8.jpg
order: 2021049
---
