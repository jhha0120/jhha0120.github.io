---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "Nightscape#7"
caption: "Nightscape#7_acrylic,oil on canvas_73×61㎝_2021"
image: /assets/images/artworks/2021/nightscape-7.jpg
thumb: /assets/images/artworks/2021/thumbs/nightscape-7.jpg
order: 2021087
---
