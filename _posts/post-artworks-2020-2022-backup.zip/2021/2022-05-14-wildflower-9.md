---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "wildflower#9"
caption: "wildflower#9_oil on panel_24×19㎝_2021"
image: /assets/images/artworks/2021/wildflower-9.jpg
thumb: /assets/images/artworks/2021/thumbs/wildflower-9.jpg
order: 2021001
---
