---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "sommer-mountain"
caption: "sommer-mountain_acrylic,oil on canvas_73×50㎝_2021"
image: /assets/images/artworks/2021/sommer-mountain.jpg
thumb: /assets/images/artworks/2021/thumbs/sommer-mountain.jpg
order: 2021053
---
