---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "landscape-structure #26(iceberg)"
caption: "landscape-structure #26(iceberg)_acrylic,oil on canvas_162×132㎝_2021"
image: /assets/images/artworks/2021/landscape-structure--26_iceberg.jpg
thumb: /assets/images/artworks/2021/thumbs/landscape-structure--26_iceberg.jpg
order: 2021090
---
