---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "sunset-mountain"
caption: "sunset-mountain_acrylic,oil on canvas_53×46㎝_2021"
image: /assets/images/artworks/2021/sunset-mountain.jpg
thumb: /assets/images/artworks/2021/thumbs/sunset-mountain.jpg
order: 2021052
---
