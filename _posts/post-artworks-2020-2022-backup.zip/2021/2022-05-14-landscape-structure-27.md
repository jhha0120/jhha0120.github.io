---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "landscape-structure#27"
caption: "landscape-structure#27_acrylic,oil on canvas_91×117㎝_2021"
image: /assets/images/artworks/2021/landscape-structure-27.jpg
thumb: /assets/images/artworks/2021/thumbs/landscape-structure-27.jpg
order: 2021089
---
