---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "Gemstone isle#2(Mont Blanc)"
caption: "Gemstone isle#2(Mont Blanc)_acrylic,oil on canvas_205×205㎝_2022"
image: /assets/images/artworks/2022/gemstone-isle-2_mont-blanc.jpg
thumb: /assets/images/artworks/2022/thumbs/gemstone-isle-2_mont-blanc.jpg
order: 2022039
---
