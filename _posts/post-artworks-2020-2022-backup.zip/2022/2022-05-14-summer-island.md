---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "summer island"
caption: "summer island_acrylic,oil on canvas_73×61㎝_2022"
image: /assets/images/artworks/2022/summer-island.jpg
thumb: /assets/images/artworks/2022/thumbs/summer-island.jpg
order: 2022035
---
