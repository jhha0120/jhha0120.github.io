---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "coast structure#1"
caption: "coast structure#1_acrylic,oil on canvas_41×53㎝_2022"
image: /assets/images/artworks/2022/coast-structure-1.jpg
thumb: /assets/images/artworks/2022/thumbs/coast-structure-1.jpg
order: 2022019
---
