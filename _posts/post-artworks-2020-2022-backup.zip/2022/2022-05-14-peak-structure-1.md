---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "Peak structure#1"
caption: "Peak structure#1_acrylic,oil on canvas_150×105㎝_2022"
image: /assets/images/artworks/2022/peak-structure-1.jpg
thumb: /assets/images/artworks/2022/thumbs/peak-structure-1.jpg
order: 2022037
---
