---
layout: "artwork"
categories: "2022-2021"
author: "Jihoon Ha"
title: "sunset island"
caption: "sunset island_acrylic,oil on canvas_73×61㎝_2022"
image: /assets/images/artworks/2022/sunset-island.jpg
thumb: /assets/images/artworks/2022/thumbs/sunset-island.jpg
order: 2022036
---
